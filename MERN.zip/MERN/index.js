const express=require("express")
const mongoose=require("mongoose")
const bodyParser=require("body-parser")

const cors=require("cors")

const app=express()
app.use(cors())

//import models
require("./modles/profile")

//connect 
mongoose.connect(`mongodb://localhost:27017/mern`,{
    useNewUrlParser:true,
    useUnifiedTopology:true,
})
.then(()=>{console.log("Mongo DB has been connected")})
.catch((err)=>{console.log(err)})


app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json())

//import routes
require("./routes/profileRoute.js")(app);

const PORT=process.env.PORT || 5000;

app.listen(PORT,()=>{
    console.log(`server running on port ${PORT}`)
});